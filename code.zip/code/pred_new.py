import pandas as pd
import numpy as np
import json

from cleandata import clean_data

# Load saved model artifacts
artifacts = np.load('rf_model_artifacts_with_code.npz')
scaler_params = json.loads(artifacts['scaler_params'].item())
vocab_movie = json.loads(artifacts['vocab_movie'].item())
vocab_drink = json.loads(artifacts['vocab_drink'].item())
trees = json.loads(artifacts['trees'].item())

# Label index mapping (order matters!)
LABELS = ['pizza', 'shawarma', 'sushi']

def standardize_numeric(row, feature_name, mean, std):
    val = row[feature_name]
    return (val - mean) / std if std != 0 else 0.0

def tfidf_vectorize(text, vocab):
    vec = np.zeros(len(vocab))
    if pd.isna(text):
        return vec
    for word in text.lower().split():
        if word in vocab:
            vec[vocab[word]] += 1
    return vec

def predict_tree(tree, x):
    node = 0
    while tree['children_left'][node] != -1:
        feature_index = tree['feature'][node]
        threshold = tree['threshold'][node]
        if x[feature_index] <= threshold:
            node = tree['children_left'][node]
        else:
            node = tree['children_right'][node]
    return np.argmax(tree['value'][node])

def predict_all(csv_filename):
    # df = pd.read_csv(csv_filename)
    df = clean_data(csv_filename)
    return predict_cleaned(df)


def predict_cleaned(df):
    predictions = []

    for _, row in df.iterrows():
        # Apply domain-specific price rules
        if row['Q4_price'] == -1:
            predictions.append('pizza')
            continue
        elif row['Q4_price'] == -2:
            predictions.append('sushi')
            continue
        # elif row['Q4_price'] == -3:
        #     predictions.append('pizza')  # Or use more logic
        #     continue

        # Standardize numeric features
        x_numeric = []
        for i, feature in enumerate(scaler_params['features']):
            x_numeric.append(standardize_numeric(row, feature, scaler_params['mean'][i], scaler_params['scale'][i]))

        # Vectorize text features
        vec_movie = tfidf_vectorize(str(row.get('Q5_movie', '')), vocab_movie)
        vec_drink = tfidf_vectorize(str(row.get('Q6_drink', '')), vocab_drink)

        # Combine all features
        x = np.concatenate([x_numeric, vec_movie, vec_drink])

        # Run each tree and vote
        votes = [predict_tree(tree, x) for tree in trees]
        majority = max(set(votes), key=votes.count)
        predictions.append(LABELS[majority])

    return predictions

if __name__ == "__main__":
    input_file = "cleaned_data_combined_modified.csv"
    preds = predict_all(input_file)
    df = clean_data(input_file)

    total_right = 0
    for i, p in enumerate(preds):
        label = df.iloc[i][df.columns[1]]
        correct_pred = label == p
        print(f"Row {i}: {p} ({label}; {correct_pred})")
        total_right += correct_pred
    print(f"Final accuracy: ({total_right}/{len(preds)})", total_right / len(preds))
