import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, accuracy_score

# Load cleaned dataset
df = pd.read_csv("transformed_survey_data.csv")

# Separate target and features
y = df["Label"]
X = df.drop(columns=["Label", "id"])

# Define features
numeric_features = [
    'Q1_complexity', 'Q2_ingredients',
    'Q3_setting_week_day_lunch', 'Q3_setting_week_day_dinner', 
    'Q3_setting_weekend_lunch', 'Q3_setting_weekend_dinner',
    'Q3_setting_at_a_party', 'Q3_setting_late_night_snack',
    'Q4_price', 'Q7_has_parents', 'Q7_has_siblings', 
    'Q7_has_friends', 'Q7_has_teachers', 'Q7_has_strangers', 
    'Q8_hot_sauce_level'
]
text_features = ['Q5_movie', 'Q6_drink']

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

# Define text and numeric transformers
text_transformer = Pipeline([
    ('tfidf', TfidfVectorizer())
])

preprocessor = ColumnTransformer([
    ('num', StandardScaler(), numeric_features),
    ('text_movie', text_transformer, 'Q5_movie'),
    ('text_drink', text_transformer, 'Q6_drink')
])

# with open('random_forest.csv', mode='w', newline="") as f:
#     import csv
#     writer = csv.writer(f)
#     for max_depth in [3, 5, 7, 9, 11, None]:
#         for min_samples_leaf in [1, 2, 3, 4, 5]:
#             for min_samples_split in [2, 4, 6, 8, 10, 12, 14, 16]:
max_depth, min_samples_split, min_samples_leaf = None, 14, 1
# Build full pipeline with Random Forest
rf_pipeline = Pipeline([
    ('preprocess', preprocessor),
    ('clf', RandomForestClassifier(n_estimators=100, random_state=42,
                                   max_depth=max_depth,
                                   min_samples_split=min_samples_split,
                                   min_samples_leaf=min_samples_leaf))
])

# Train model
rf_pipeline.fit(X_train, y_train)

# Predict and evaluate
y_pred = rf_pipeline.predict(X_test)
print(classification_report(y_test, y_pred))
# writer.writerow([max_depth, min_samples_split, min_samples_leaf, accuracy_score(y_test, y_pred)])
