import pandas as pd
import numpy as np
import json

from sklearn.metrics import classification_report
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier

# === 1. Load cleaned training data ===
df = pd.read_csv("transformed_survey_data.csv")
X = df.drop(columns=["Label", "id"])
y = df["Label"]

# === 2. Define feature groups ===
numeric_features = [
    'Q1_complexity', 'Q2_ingredients',
    'Q3_setting_week_day_lunch', 'Q3_setting_week_day_dinner', 
    'Q3_setting_weekend_lunch', 'Q3_setting_weekend_dinner',
    'Q3_setting_at_a_party', 'Q3_setting_late_night_snack',
    'Q4_price', 'Q7_has_parents', 'Q7_has_siblings', 
    'Q7_has_friends', 'Q7_has_teachers', 'Q7_has_strangers', 
    'Q8_hot_sauce_level'
]
text_features = ['Q5_movie', 'Q6_drink']

# === 3. Split the data (optional, for cross-validation only) ===
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

# === 4. Preprocessing and pipeline ===
text_transformer = Pipeline([
    ('tfidf', TfidfVectorizer())
])

preprocessor = ColumnTransformer([
    ('num', StandardScaler(), numeric_features),
    ('text_movie', text_transformer, 'Q5_movie'),
    ('text_drink', text_transformer, 'Q6_drink')
])

rf_pipeline = Pipeline([
    ('preprocess', preprocessor),
    ('clf', RandomForestClassifier(n_estimators=100, random_state=42, min_samples_split=14, min_samples_leaf=1))
])

# === 5. Train the model ===
rf_pipeline.fit(X_train, y_train)

y_pred = rf_pipeline.predict(X_test)
print(classification_report(y_test, y_pred))


# === 6. Extract components for manual prediction ===
scaler = rf_pipeline.named_steps["preprocess"].named_transformers_["num"]
vectorizer_movie = rf_pipeline.named_steps["preprocess"].named_transformers_["text_movie"].named_steps["tfidf"]
vectorizer_drink = rf_pipeline.named_steps["preprocess"].named_transformers_["text_drink"].named_steps["tfidf"]
forest = rf_pipeline.named_steps["clf"]

# === 7. Prepare scaler data ===
scaler_params = {
    "mean": scaler.mean_.tolist(),
    "scale": scaler.scale_.tolist(),
    "features": numeric_features
}

# === 8. Prepare vocabularies ===
vocab_movie = vectorizer_movie.vocabulary_
vocab_drink = vectorizer_drink.vocabulary_

# === 9. Export top 10 trees ===
exported_trees = []
for tree in forest.estimators_[:10]:
    t = tree.tree_
    exported_trees.append({
        "children_left": t.children_left.tolist(),
        "children_right": t.children_right.tolist(),
        "feature": t.feature.tolist(),
        "threshold": t.threshold.tolist(),
        "value": t.value.squeeze(axis=1).tolist()
    })

# === 10. Save everything to rf_model_artifacts.npz ===
np.savez(
    "rf_model_artifacts_with_code.npz",
    scaler_params=json.dumps(scaler_params),
    vocab_movie=json.dumps(vocab_movie),
    vocab_drink=json.dumps(vocab_drink),
    trees=json.dumps(exported_trees)
)

print("✅ Saved model artifacts to rf_model_artifacts_with_code.npz")
